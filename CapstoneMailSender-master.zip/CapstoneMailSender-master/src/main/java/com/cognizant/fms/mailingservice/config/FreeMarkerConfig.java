package com.cognizant.fms.mailingservice.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.ui.freemarker.FreeMarkerConfigurationFactoryBean;


@Configuration
public class FreeMarkerConfig {
	/*
	 * 
	 * @Bean public FreeMarkerConfigurationFactoryBean getFreeMarkerConfiguration()
	 * { FreeMarkerConfigurationFactoryBean bean = new
	 * FreeMarkerConfigurationFactoryBean();
	 * bean.setTemplateLoaderPath("/templates/"); return bean; }
	 */
}

