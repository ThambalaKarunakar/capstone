package com.capstone.jwt.model;

public enum Role {
	ROLE_ADMIN,ROLE_PMO,ROLE_ADMIN_POC
}