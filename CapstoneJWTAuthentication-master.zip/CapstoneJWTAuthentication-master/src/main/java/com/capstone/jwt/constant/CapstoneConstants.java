/*package com.capstone.jwt.constant;

import org.springframework.http.HttpStatus;

public class CapstoneConstants {
	
	public static final ABC = 401;

}
*/