/*package com.capstone.jwt.service;

import com.capstone.jwt.model.CapstoneJwtRespone;
import com.capstone.jwt.model.CapstoneUserDetails;

import reactor.core.publisher.Mono;

public interface CapstoneJwtService {
	
	Mono<CapstoneJwtRespone> findUserDetails(CapstoneUserDetails userDetails);

}
*/