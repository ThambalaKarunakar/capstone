/**
 * Default {@code RowMapper} implementations.
 */
package org.springframework.batch.item.excel.mapping;